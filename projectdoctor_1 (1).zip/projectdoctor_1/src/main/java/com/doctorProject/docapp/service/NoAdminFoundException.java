package com.doctorProject.docapp.service;

public class NoAdminFoundException extends Exception {

	public NoAdminFoundException(String string) {
		super(string);
	}

}
