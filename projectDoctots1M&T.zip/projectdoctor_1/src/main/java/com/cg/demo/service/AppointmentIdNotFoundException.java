package com.cg.demo.service;

public class AppointmentIdNotFoundException extends Exception {

	public AppointmentIdNotFoundException(String string) {
		super(string);
	}

}
