package com.cg.demo.service;

import java.util.List;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.dao.AppointmentRepository;
import com.cg.demo.entities.Appointment;
import com.doctorProject.docapp.exception.AppointmentNotFoundException;
import com.cg.demo.entities.Appointment;
//import com.doctorProject.docapp.entity.Appointment;
//import com.doctorProject.docapp.repository.AppointmentRepository;




@Service("appoinmentService")
public  class AppointmentService {

  @Autowired
  AppointmentRepository appointmentRepository;

  public Appointment getAppointment(int appointmentid) {
      return appointmentRepository.findById(appointmentid);
  }

  public Appointment addAppointment(Appointment app) {
      return appointmentRepository.save(app);
  }

  public Appointment deleteAppointment(int appointmentid) {
      Appointment appointment = appointmentRepository.findById(appointmentid);
      appointmentRepository.delete(appointment);
      return appointment;
  }

  public Appointment updateAppointment(Appointment app) {
      return appointmentRepository.save(app);
  }

  public List<Appointment> getAppointments(LocalDate date) {
      return appointmentRepository.findByDate(date);
  }

  public List<Appointment> findAll() throws Exception {
		List<Appointment> list = appointmentRepository.findAll();
		if (list.isEmpty())
			throw new AppointmentNotFoundException("No Admin Found!!");
		return list;
	}
}
