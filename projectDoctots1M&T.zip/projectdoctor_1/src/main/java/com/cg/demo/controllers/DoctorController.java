package com.cg.demo.controllers;

import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.demo.entities.Doctor;
import com.cg.demo.entities.Availability;
import com.cg.demo.entities.Doctor;
import com.cg.demo.service.AvailabilityService;
import com.cg.demo.service.DoctorService;

@RestController
public class DoctorController {
	@Autowired
	DoctorService ds;
	AvailabilityService avs;
	
	@PostMapping("/doctors")
	public ResponseEntity<String> addDoctor(@Valid@RequestBody Doctor doc) {
		String msg=ds.insertDoctor(doc);
		ResponseEntity<String> rEntity=new ResponseEntity<String>(msg,HttpStatus.CREATED);
		return rEntity;
	}
	@PostMapping("/authenticateDoctor")
	public String authenticateDoctor(@Valid@RequestBody Doctor doc) {
		return ds.authenticateDoctor(doc);
	}
	@PutMapping("/doctors/{id}")
	public ResponseEntity<String> modifyDoctor(@PathVariable ("id") int id, @Valid@RequestBody Doctor doc) {
		String msg=ds.updateDoctor(id,doc);
		ResponseEntity<String> rEntity=new ResponseEntity<String>(msg,HttpStatus.ACCEPTED);
		return rEntity;
	}
//	@PostMapping("/doctors/{id}/avalibilitys/{id}")
//	public ResponseEntity<String> addAvalibility(@Valid@RequestBody Avalibility aval) {
//		String msg=avs.insertAvalibility(aval);
//		ResponseEntity<String> rEntity=new ResponseEntity<String>(msg,HttpStatus.CREATED);
//		return rEntity;
//	}
//	@PutMapping("/doctors/{id}/avalibilitys/{id}")
//	public ResponseEntity<String> modifyAvalibility(@PathVariable ("id") int id, @Valid@RequestBody Avalibility aval) {
//		String msg=avs.updateAvalibility(id,aval);
//		ResponseEntity<String> rEntity=new ResponseEntity<String>(msg,HttpStatus.ACCEPTED);
//		return rEntity;
//	}
	@GetMapping("/doctors/{id}")
	public ResponseEntity<Doctor> findDoctorById(@PathVariable("id") int id){
		Doctor dr =ds.findByDoctorId(id);
		ResponseEntity<Doctor> rEntity=new ResponseEntity<Doctor>(dr,HttpStatus.OK);
		return rEntity;
	}
	@DeleteMapping("/doctors/{id}")
	public ResponseEntity<String> deleteDoctorById(@PathVariable ("id")int id) {
		String msg=ds.deleteById(id);
		ResponseEntity<String> rEntity=new ResponseEntity<String>(msg,HttpStatus.ACCEPTED);
		return rEntity;
	}
	@GetMapping("/doctors")
	public List<Doctor> fetchAllDoctor(){
		return ds.findAll();
	}
	@GetMapping("/doctors/bySpecility/{sName}")
	public List<Doctor> findDoctorBySpecility(@PathVariable("sName") String specialization){
		return ds.findByDoctorSpecility(specialization);
	}
	@GetMapping("/doctors/{id}/patients")
	public List<Patient> getPatientListById() {
		
		String url="http://localhost:8095/patients/";
		RestTemplate rt=new RestTemplate();
		List<Patient> list=Arrays.asList(rt.getForObject(url, Patient[].class));
		return list;
	}
//	@GetMapping("/doctors/{id}/appointments")
//	public List<Appointment> getAppointmentById() {
//		
//		String url="";
//		RestTemplate rt=new RestTemplate();
//		List<Appointment> list=Arrays.asList(rt.getForObject(url, Appointment[].class));
//		return list;
//	}
//	@GetMapping("/doctors/{id}/appointments/{id}")
//	public ResponseEntity<Appointment> getAppointmentById(@PathVariable("id") int id) {
//		
//		String url=""+id;
//		RestTemplate rt=new RestTemplate();
//		ResponseEntity rEntity=rt.getForObject(url, ResponseEntity.class);
//		return rEntity;
//	}
//	@GetMapping("/doctors/{id}/feedbacks")
//	public List<Feedback> getFeedbackById() {
//		
//		String url="";
//		RestTemplate rt=new RestTemplate();
//		List<Feedback> list=Arrays.asList(rt.getForObject(url, Feedback[].class));
//		return list;
//	}
//	@GetMapping("/doctors/{id}/")
//	public List<Appointment> getAppointmentById() {
//		
//		String url="";
//		RestTemplate rt=new RestTemplate();
//		List<Appointment> list=Arrays.asList(rt.getForObject(url, Appointment[].class));
//		return list;
//	}
	

}
