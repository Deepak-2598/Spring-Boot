package com.cg.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.demo.entities.Patient;
import com.demo.doctor.exceptions.PatientIdMismatchException;
import com.demo.doctor.responses.ErrorInfo;
import com.cg.demo.service.PatientService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class PatientController {
	@Autowired PatientService ps;
	//@Autowired RestTemplate rt;
	
	
	@Operation(summary = "Add Patient")
	@ApiResponses(value = { 
			@ApiResponse(responseCode =  "200", description = "OK", content= @Content(mediaType = "application/json",schema= @Schema(oneOf = Patient.class)))
	})
	@PostMapping("/patients")
	public ResponseEntity <Patient> addPatient(@RequestBody Patient p) {
		Patient str=  ps.addPatient(p);
		ResponseEntity <Patient> rEntity = new ResponseEntity<Patient>(str, HttpStatus.OK);
		return rEntity;
	}
	@Operation(summary = "Get Patient ById")
	@GetMapping("/patients/{id}")
	@ApiResponses(value = { 
			@ApiResponse(responseCode =  "200", description = "OK", content= @Content(mediaType = "application/json",schema= @Schema(oneOf = Patient.class))),
			@ApiResponse(responseCode =  "404", description = "NOT_FOUND", content= @Content(mediaType = "application/json",schema= @Schema(oneOf = ErrorInfo.class)))
	})
	public ResponseEntity<Patient> getPatient(@PathVariable int id) {
		Patient p= ps.getPatient(id);
		ResponseEntity <Patient> rEntity = new ResponseEntity<Patient>(p, HttpStatus.OK);
		return rEntity;
	}
	
	@Operation(summary = "Get All Patients")
	@ApiResponses(value = { 
			@ApiResponse(responseCode =  "200", description = "OK", content= @Content(mediaType = "application/json",schema= @Schema(oneOf = Patient.class)))
	})
	@GetMapping("/patients")
	public ResponseEntity<List<Patient>> getAllPatient( ){
		List<Patient> list =  ps.getAllPatient(); 
		ResponseEntity <List<Patient>> rEntity = new ResponseEntity<List<Patient>>(list, HttpStatus.FOUND);
		return rEntity;
	}
	
	@Operation(summary = "Update Patient ById")
	@PutMapping("/patients/{id}")
	
	public ResponseEntity<String> updatePatientDetails(@PathVariable int id,@RequestBody Patient p) throws PatientIdMismatchException {
		String str = ps.updatePatientDetails(id, p);
		ResponseEntity <String> rEntity = new ResponseEntity<String>(str, HttpStatus.ACCEPTED);
		return rEntity;
	}
	@Operation(summary = "Delete PatientById")
	@DeleteMapping("/patients/{id}")
	public ResponseEntity<String> removePatientDetails(@PathVariable int id) {
		String str = ps.removePatientDetails(id);
		ResponseEntity <String> rEntity = new ResponseEntity<String>(str, HttpStatus.OK);
		return rEntity;
	}
}
