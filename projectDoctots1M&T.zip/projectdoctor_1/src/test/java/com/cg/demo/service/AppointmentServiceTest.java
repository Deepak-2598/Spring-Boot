package com.cg.demo.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.cg.demo.dao.AppointmentRepository;
import com.cg.demo.entities.Appointment;

class AppointmentServiceTest {

  @Mock
  AppointmentRepository appointmentRepository;

  @InjectMocks
  AppointmentService appointmentService;

  @Spy
  List<Appointment> appointments = new ArrayList<Appointment>();
  
  @BeforeEach
  public void setUp() {
    //MockitoAnnotations.initMocks(this);
    appointments = getAppointments();
  }

  private List<Appointment> getAppointments() {
    Appointment appointment1 = new Appointment(1, null, LocalDate.of(2022, 11, 11), 0, 0, "Consultation", null, null);
    Appointment appointment2 = new Appointment(2, null, LocalDate.of(2022, 11, 12), 0, 0, "Surgery", null, null);
    appointments.add(appointment1);
    appointments.add(appointment2);
    return appointments;
  }

  @Test
  public void testGetAppointment() {
    Appointment appointment = new Appointment(1, null, LocalDate.of(2022, 11, 11), 0, 0, "Consultation", null, null);
    when(appointmentRepository.findById(1)).thenReturn(appointment);
    Appointment result = appointmentService.getAppointment(1);
    assertEquals(appointment, result);
  }

  @Test
  public void testAddAppointment() {
    Appointment appointment = new Appointment(3, null, LocalDate.of(2022, 11, 13), 0, 0, "Checkup", null, null);
    when(appointmentRepository.save(appointment)).thenReturn(appointment);
    Appointment result = appointmentService.addAppointment(appointment);
    assertEquals(appointment, result);
  }

  @Test
  public void testDeleteAppointment1() {
    Appointment appointment = new Appointment();
    doNothing().when(appointmentRepository).delete(appointment);
    appointmentService.deleteAppointment(1);
    verify(appointmentRepository, atLeastOnce()).delete(appointment);
  }

  @Test
  public void testUpdateAppointment() {
    Appointment appointment = new Appointment(1, null, LocalDate.of(2022, 11, 11), 0, 0, "Consultation", null, null);
    when(appointmentRepository.save(appointment)).thenReturn(appointment);
    Appointment result = appointmentService.updateAppointment(appointment);
    assertEquals(appointment, result);
    verify(appointmentRepository, times(1)).save(appointment);
  }

  @Test
  public void testDeleteAppointment() {
  Appointment appointment = new Appointment(1, null, LocalDate.of(2022, 11, 11), 0, 0, "Consultation", null, null);
  when(appointmentRepository.findById(1)).thenReturn(appointment);
  doNothing().when(appointmentRepository).delete(appointment);
  Appointment result = appointmentService.deleteAppointment(1);
  assertEquals(appointment, result);
  verify(appointmentRepository, times(1)).findById(1);
  verify(appointmentRepository, times(1)).delete(appointment);
  }

  @Test
  public void testGetAppointments() {
  List<Appointment> appointmentList = new ArrayList<>();
  appointmentList.add(new Appointment(1, null, LocalDate.of(2022, 11, 11), 0, 0, "Consultation", null, null));
  appointmentList.add(new Appointment(2, null, LocalDate.of(2022, 11, 11), 0, 0, "Checkup", null, null));
  when(appointmentRepository.findByDate(LocalDate.of(2022, 11, 11))).thenReturn(appointmentList);
  List<Appointment> result = appointmentService.getAppointments(LocalDate.of(2022, 11, 11));
  assertEquals(appointmentList, result);
  verify(appointmentRepository, times(1)).findByDate(LocalDate.of(2022, 11, 11));
  }

  @Test
  public void testFindAll() throws Exception {
  List<Appointment> appointmentList = new ArrayList<>();
  appointmentList.add(new Appointment(1, null, LocalDate.of(2022, 11, 11), 0, 0, "Consultation", null, null));
  appointmentList.add(new Appointment(2, null, LocalDate.of(2022, 11, 11), 0, 0, "Checkup", null, null));
  when(appointmentRepository.findAll()).thenReturn(appointmentList);
  List<Appointment> result = appointmentService.findAll();
  assertEquals(appointmentList, result);
  verify(appointmentRepository, times(1)).findAll();
  }
  
  }
