package com.doctorProject.docapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projectdoctor1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
