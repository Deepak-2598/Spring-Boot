package com.doctorProject.docapp.exception;

//package com.doctorProject.docapp.service;

public class AppointmentNotFoundException extends Exception {

	public AppointmentNotFoundException(String string) {
		super(string);
	}

}
