package com.cg.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.dao.PatientDao;
import com.cg.demo.entities.Patient;
import com.demo.doctor.exceptions.PatientIdMismatchException;
import com.demo.doctor.exceptions.PatientNotFoundException;

@Service("ps")
public class PatientService {
	@Autowired
	PatientDao pd;
	public Patient addPatient(Patient p) {
		Patient obj = pd.save(p);
		//return "Added Successfully - patientId:"+ obj.getPatientId() ;
		return obj;
	}
	
	public Patient getPatient(int id) throws PatientNotFoundException {
		Optional<Patient> obj = pd.findById(id);
		if(obj.isEmpty()) throw new PatientNotFoundException("Patient Not Found - id:"+id);
			return obj.get();
	}
	public List<Patient> getAllPatient( ){
		return pd.findAll();
	}
	public String updatePatientDetails(int id,Patient p)throws PatientIdMismatchException {
		if(id!=p.getPatientId())
			throw new PatientIdMismatchException("Patient Id MisMatch");
		Patient obj=pd.save(p);
		return "Updated Successfully - patientId:"+ obj.getPatientId() ;
	}
	public String removePatientDetails(int id) throws PatientNotFoundException{
		if(!pd.existsById(id))
			throw new PatientNotFoundException("Patient Not Found - id:"+id);
		pd.deleteById(id);
		return "Deleted Successfully - patientId:"+ id;	
	}
}

	
	
	

