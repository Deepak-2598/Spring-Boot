package com.cg.demo.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;


@Data

@Entity
@Table(name="Patient")
public class Patient {
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "patient_id")
	private int patientId;
	@NotEmpty
	private String patientName;
	@NotEmpty
	@Column(length=10,nullable=false)
	private String patientPhone;
	@Email
	private String email;
	@NotEmpty
	private String password;
	//@NotEmpty
	@NotNull
	private int age;
	@NotNull
	private float weight;
	@NotEmpty
	private String bloodGroup;
	@NotEmpty
	private String address;
	@NotEmpty
	private String gender;
	
	@JsonIgnore
	@OneToOne(mappedBy = "patient")
	private PatientIssue patientIssue;
}
