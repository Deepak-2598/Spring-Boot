package com.cg.demo.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.cg.demo.dao.DoctorDao;
import com.cg.demo.entities.Doctor;
import com.demo.doctor.exceptions.DoctorIdNotFoundException;
import com.demo.doctor.exceptions.IdNotMatchedException;
import com.demo.doctor.exceptions.NoDoctorFoundException;

@Service("ds")
public class DoctorService{
	
	@Autowired
	DoctorDao dd;
	
	public String authenticateDoctor(Doctor doc) throws NoDoctorFoundException{
		BCryptPasswordEncoder bcrypt=new BCryptPasswordEncoder();
		Optional<Doctor> opDoctor=dd.findById(doc.getDoctor_Id());
		if(opDoctor.isPresent()) {
			Doctor dbDoctor=opDoctor.get();
			if(bcrypt.matches(doc.getPassword(), dbDoctor.getPassword()))
				return "Authenticated User";
			else
				return"Incorrect Password";
		}
		throw new NoDoctorFoundException("No Doctor is not found for this email!!!");
	}
	
	public String insertDoctor(Doctor doc) {
		BCryptPasswordEncoder bcrypt=new BCryptPasswordEncoder();
		String encryptedPwd=bcrypt.encode(doc.getPassword());
		doc.setPassword(encryptedPwd);
		Doctor dbdr=dd.save(doc);
		return "Added Successfully with Id:"+dbdr.getDoctor_Id();
	}
	  
	 public String updateDoctor(int id, Doctor doc) { 
		 if(id==doc.getDoctor_Id()) {
	  if(dd.existsById(id)) { Doctor updr=dd.save(doc); 
	  return "Updated Successfully for id:"+updr.getDoctor_Id(); } 
	  else throw new DoctorIdNotFoundException("Doctor Not found for Id :"+id); } 
		 throw new IdNotMatchedException("Id is not matched in Path Variable and in the request body :"+id); }
	  
	  public Doctor findByDoctorId(int id) { 
		  Optional<Doctor> op=dd.findById(id);
	  if(op.isPresent()) 
		  return op.get(); 
	  else throw new DoctorIdNotFoundException("Doctor Not found for Id :"+id); 
	  }
	  
	  public String deleteById(int id) { 
		  if(dd.existsById(id)){ dd.deleteById(id);
	  return "Deleted Successfully for Id:"+id; } 
		  throw new DoctorIdNotFoundException("Doctor Not found for Id :"+id); 
		  }
	  
	  public List<Doctor> findAll() { 
		  List<Doctor> list=dd.findAll();
	  if(list.isEmpty()) 
		  throw new NoDoctorFoundException("No Doctor Found ");
	  return list; 
	  }
	  
	public List<Doctor> findByDoctorSpecility(String specialization) {
		List<Doctor> list=dd.findAllBySpecialization(specialization);
		if(list.isEmpty())
			throw new DoctorIdNotFoundException("Doctor Not found for specialization :"+specialization);
		return list;	
	}

	
}
