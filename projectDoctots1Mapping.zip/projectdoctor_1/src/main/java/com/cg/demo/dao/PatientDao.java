package com.cg.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.demo.entities.Patient;

@Repository("pd")
public interface PatientDao extends JpaRepository<Patient,Integer>{
	
}