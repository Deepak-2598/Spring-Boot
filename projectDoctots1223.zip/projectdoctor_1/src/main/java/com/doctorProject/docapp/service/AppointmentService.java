package com.doctorProject.docapp.service;


//package com.docapp.service;

import java.util.List;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doctorProject.docapp.entity.Appointment;
import com.doctorProject.docapp.repository.AppointmentRepository;
//import com.doctorProject.docapp.serviceImpl.AppointmentServiceImpl;



@Service("appoinmentService")
public  class AppointmentService {

  @Autowired
  AppointmentRepository appointmentRepository;

  public List<Appointment> getAllAppointments() {
      return appointmentRepository.findAll();
  }

  public Appointment getAppointment(int appointmentid) {
      return appointmentRepository.findById(appointmentid);
  }

  public Appointment addAppointment(Appointment app) {
      return appointmentRepository.save(app);
  }

  public Appointment deleteAppointment(int appointmentid) {
      Appointment appointment = appointmentRepository.findById(appointmentid);
      appointmentRepository.delete(appointment);
      return appointment;
  }

  public Appointment updateAppointment(Appointment app) {
      return appointmentRepository.save(app);
  }

 /* @Override
  public List<Appointment> getAppointments(Doctor doc) {
      return appointmentRepository.findByDoctor(doc);
  }*/

  public List<Appointment> getAppointments(LocalDate date) {
      return appointmentRepository.findByDate(date);
  }
}
