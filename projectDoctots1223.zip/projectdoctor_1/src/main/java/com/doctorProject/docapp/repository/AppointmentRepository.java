package com.doctorProject.docapp.repository;

import java.util.List;
import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.doctorProject.docapp.entity.Appointment;



@Repository("appointmentRepository")
public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {
    List<Appointment> findAll();
    Appointment findById(int appointmentid);
    List<Appointment> findByDoctorId(Appointment doc);
    List<Appointment> findByDate(LocalDate date);
}