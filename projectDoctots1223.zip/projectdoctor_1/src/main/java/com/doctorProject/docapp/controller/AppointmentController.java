package com.doctorProject.docapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.doctorProject.docapp.entity.Appointment;
import com.doctorProject.docapp.service.AppointmentService;

import antlr.collections.List;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
public class AppointmentController {

    @Autowired
    AppointmentService appointmentService;

    @GetMapping("/appointments")
    public List getAllAppointments(Appointment appointment) {
       List appointments = (List) appointmentService.getAllAppointments();
       return (List) ResponseEntity.ok().body(appointments);
    }

    @GetMapping("/appointments/{id}")
    public ResponseEntity<Appointment> getAppointment(@PathVariable int id) {
        Appointment appointment = appointmentService.getAppointment(id);
        if (appointment == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(appointment);
    }

    @PostMapping("/appointments")
    public ResponseEntity<Appointment> addAppointment(@RequestBody Appointment appointment) {
        Appointment createdAppointment = appointmentService.addAppointment(appointment);
        return ResponseEntity.ok().body(createdAppointment);
    }

    @PutMapping("/appointments/{id}")
    public ResponseEntity<Appointment> updateAppointment(@PathVariable int id, @RequestBody Appointment appointment) {
        Appointment updatedAppointment = appointmentService.updateAppointment(appointment);
        if (updatedAppointment == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(updatedAppointment);
    }

    @DeleteMapping("/appointments/{id}")
    public ResponseEntity<Appointment> deleteAppointment(@PathVariable int id) {
        Appointment deletedAppointment = appointmentService.deleteAppointment(id);
        if (deletedAppointment == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(deletedAppointment);
    }

}