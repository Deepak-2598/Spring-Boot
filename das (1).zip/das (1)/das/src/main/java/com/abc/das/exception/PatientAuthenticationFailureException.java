package com.abc.das.exception;

public class PatientAuthenticationFailureException extends RuntimeException {

	public PatientAuthenticationFailureException(String msg) {
		super(msg);
	} 

}
