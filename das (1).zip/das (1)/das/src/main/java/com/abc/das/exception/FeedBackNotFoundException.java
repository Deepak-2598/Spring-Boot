package com.abc.das.exception;

public class FeedBackNotFoundException extends RuntimeException  {
	public FeedBackNotFoundException(String msg)
	{
		super(msg);
	}

}
