package com.doctorProject.docapp.serviceImpl;


import java.util.List;

import com.doctorProject.docapp.entity.Appointment;

import java.time.LocalDate;



public interface AppointmentServiceImpl {
    List<Appointment> getAllAppointments();
    Appointment getAppointment(int appointmentid);
    Appointment addAppointment(Appointment app);
    Appointment deleteAppointment(int appointmentid);
    Appointment updateAppointment(Appointment app);
    //List<Appointment> getAppointments(Doctor doc);
    List<Appointment> getAppointments(LocalDate date);
}